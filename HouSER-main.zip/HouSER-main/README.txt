## houSER
Um aplicativo para pessoas buscarem espaço e também ofertarem espaço disponível 

## Tecnologias 

As tecnologias utilizadas nesse projeto foram:

* Javascript
* React Native

## Versionamento feito com:

* Github

## Getting started

- Rodar um npm install antes de tentar abrir o projeto.

* Dependencias
  * Dependencias de navegação.

  
