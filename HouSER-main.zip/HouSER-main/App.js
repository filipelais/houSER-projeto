import React from 'react';
import StackNavigator from './src/routes/stackNavigation';

export default function App() {
  return (
    <StackNavigator/>
  );
}